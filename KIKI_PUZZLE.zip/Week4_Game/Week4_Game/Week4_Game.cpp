﻿#define _CRT_SECURE_CPP_OVERLOAD_STANDARD_NAMES	1

#include <stdio.h>
#include <bangtal.h>
#include <stdlib.h>
#include <time.h>


SceneID GameMain;
ObjectID MadeOB, imageSave, blank, StartB, RestartB, Full_KIKI, item1, item2, Message, SelectMag, Sel1, Sel2, showFullPng, UsedOB;
ObjectID SelectCat, UsedCat;
TimerID GameTimer, imageTimer;
time_t StartTIme, FinishTime;
int k;
int Ch_x_1; int Ch_y_1;
int Ch_x_2; int Ch_y_2;
int Sel1a, Sel2a;
bool Gamerun, Gamerun2 = false;
bool RestartG = false;
bool StartBVaild = true;
bool select1, select2 = false;
bool Magic = true;
bool pic = true;


//구조체 선언
struct images1 {
	int x;
	int y;
};


//구조체 배열 변수 초기화 - 좌표 멤버를 저장
images1 spot[16] = {
	{352, 498}, {488, 498}, {624, 498}, {760, 498},
	{352, 362}, {488, 362}, {624, 362}, {760, 362},
	{352, 226}, {488, 226}, {624, 226}, {760, 226}, 
	{352, 90}, {488, 90}, {624, 90}, {760, 90}
};


//배열 선언
ObjectID imageSaveL[16];
int siteNum[16];
bool right[16] = {false};


//타이머 제작
void Timer1() {
	GameTimer = createTimer(600.0f);
	showTimer(GameTimer);
	startTimer(GameTimer);
}


// 배열에 0~15까지의 숫자 요소를 무작위 배치
void mixnumber() {
	srand(time(NULL));

	for (int i = 0; i < 16; i++) {
		siteNum[i] = rand() % 16;
		for (int j = 0; j < i; j++) {
			if (siteNum[i] == siteNum[j]) {
				i = i - 1;
				break;
			}
	
		}
		
	}
	
}


// 게임 시작, 무작위 순서의 배열에 따라 그림 랜덤 배치 
void GameReady() {
	for (int i = 0; i < 15; i++) {
		char image[20];
		sprintf(image, "images/%d.png", i + 1);
		MadeOB = createObject(image);
		imageSaveL[i] = MadeOB;
		locateObject(MadeOB, GameMain, spot[siteNum[i]].x, spot[siteNum[i]].y);
		showObject(MadeOB);
	}

	//공백(blank)는 남은 좌표에 따로 배치하기.
	blank = createObject("images/16.png");
	imageSaveL[15] = blank;
	locateObject(blank, GameMain, spot[siteNum[15]].x, spot[siteNum[15]].y);
	showObject(blank);

}


//게임 승패 판별하기
void CheckGameClear() {
	if (right[1] && right[2] && right[3] && right[4] && right[5] && right[6] 
		&& right[7] && right[8] && right[9] && right[10] && right[11] && right[12]
		&& right[13] && right[14] && right[15] && right[0]) {
		Gamerun2 = false;
		RestartG = true;
		showObject(Full_KIKI);
		stopTimer(GameTimer);

		// 클리어하는 데 걸린 시간 출력하기
		FinishTime = time(NULL);
		int Cleartime_Min = (FinishTime - StartTIme) / 60;
		int Cleartime_Sec = (FinishTime - StartTIme) % 60;

		char timeprint[100];
		sprintf(timeprint, "총 소요시간 : 약 %d분 %d초", Cleartime_Min, Cleartime_Sec);
		showMessage(timeprint);

		// 클릭 이후 메시지창을 넘기기 위해 투명 오브젝트 생성
		Message = createObject("images/Message.png");
		locateObject(Message, GameMain, 0, 0);
		showObject(Message);


	}
}


//그림이 맞는 위치에 들어갔는지 판별하고, bool 요소 상태 변환하기
void RightPlace() {
	int u;
	for (u = 0; u < 16; u++) {
		if (siteNum[u] == u) {
			right[u] = true;
		}
		else {
			right[u] = false;
		}
	}
	CheckGameClear();
}


//공백과 그림의 위치 바꾸기
void ChangeSpot() {
	int MidSave = siteNum[15];
	siteNum[15] = siteNum[k];
	siteNum[k] = MidSave;
	locateObject(imageSaveL[k], GameMain, spot[siteNum[k]].x, spot[siteNum[k]].y);
	locateObject(blank, GameMain, spot[siteNum[15]].x, spot[siteNum[15]].y);
	RightPlace();
}


//그림이 공백의 상하좌우에 위치해있을 때를 판별하여 ChangeSpot 호출
void GameMoveCheck() {

	int blnx = spot[siteNum[15]].x;
	int blny = spot[siteNum[15]].y;
	int spotv_x = spot[siteNum[k]].x;
	int spotv_y = spot[siteNum[k]].y;

	if (spotv_x == blnx - 136 && spotv_y == blny ) {
		// 빈칸이 그림 오른쪽에 있는 경우
		ChangeSpot();
	}
	else if (spotv_x == blnx + 136 && spotv_y == blny) {
		// 빈칸이 그림 왼쪽에 있는 경우
		ChangeSpot();
	}
	else if (spotv_x == blnx && spotv_y == blny +136) {
		//빈칸이 그림 아래에 있는 경우
		ChangeSpot();
	}
	else if (spotv_x == blnx && spotv_y == blny - 136) {
		//빈칸이 그림 위에 있는 경우
		ChangeSpot();
	}
	else {

	}
}

//마법봉 아이템 기능 - 두 물건 체인지하기
void ChangeWhereOB() {
	hideObject(Sel1); hideObject(Sel2); hideObject(SelectMag);
	
	int MidSave = siteNum[Sel1a];
	siteNum[Sel1a] = siteNum[Sel2a];
	siteNum[Sel2a] = MidSave;
	locateObject(imageSaveL[Sel1a], GameMain, Ch_x_2, Ch_y_2);
	locateObject(imageSaveL[Sel2a], GameMain, Ch_x_1, Ch_y_1);

	UsedOB = createObject("images/Magi_Used.png");
	locateObject(UsedOB, GameMain, 989, 368);
	showObject(UsedOB);
	RightPlace();

	pic = true;
}

void timerCallBack(TimerID timer) {
	if (timer == GameTimer) {
		Gamerun = false;
		RestartG = true;
		showMessage("시간 종료! 다시 도전해보는 건 어떨까요?");
	}

	if (timer == imageTimer) {
		hideObject(showFullPng);
		hideObject(SelectCat);
		UsedCat = createObject("images/Cat_Used.png");
		locateObject(UsedCat, GameMain, 989, 236);
		showObject(UsedCat);
		Magic = true;

	}
}


void MouseCallback1(ObjectID obj, int x, int y, MouseAction act) {
	
	if (Gamerun) {
		for (k = 0; k < 16; k++) {
			if (obj == imageSaveL[k]) {

				char imageSelect1[20];
				char imageSelect2[20];

				if (select1 && k != 15) {
					
					sprintf(imageSelect1, "images/%d_1.png", k + 1);
					Sel1 = createObject(imageSelect1);
					locateObject(Sel1, GameMain, spot[siteNum[k]].x-4, spot[siteNum[k]].y-4);
					showObject(Sel1);

					Sel1a = k;
					Ch_x_1 = spot[siteNum[k]].x;
					Ch_y_1 = spot[siteNum[k]].y;

					select1 = false;
					select2 = true;
					break;
				}

				else if (select2 && k != 15) {

					sprintf(imageSelect2, "images/%d_1.png", k + 1);
					if (imageSelect2 != imageSelect1) {
						Sel2 = createObject(imageSelect2);
						locateObject(Sel2, GameMain, spot[siteNum[k]].x-4, spot[siteNum[k]].y-4);
						showObject(Sel2);

						Sel2a = k;
						Ch_x_2 = spot[siteNum[k]].x;
						Ch_y_2 = spot[siteNum[k]].y;

						select2 = false;
						Gamerun2 = true;

						ChangeWhereOB();

						break;
					}
				}

				else if (Gamerun2) {
					GameMoveCheck();
					break;
				}
				
			}
		}

		if (obj == Message) {
			showMessage("축하합니다! 게임을 클리어하셨습니다.");
			hideObject(Message);
		}

		//아이템 사용 코드
		if (obj == item1) {
			if (Magic) {
				//마법봉 아이템: 두 개의 블록을 선택해 자유롭게 위치를 변경할 수 있다.
				SelectMag = createObject("images/Magi_Select.png");
				locateObject(SelectMag, GameMain, 984, 352);
				showObject(SelectMag);
				select1 = true;
				Gamerun2 = false;
				Magic = false;
				pic = false;
			}
			

		}

		if (obj == item2) {
			if (pic) {
				imageTimer = createTimer(3.0f);
				startTimer(imageTimer);

				showFullPng = createObject("images/KIKI.png");
				locateObject(showFullPng, GameMain, 352, 93);
				showObject(showFullPng);

				SelectCat = createObject("images/Cat_Select.png");
				locateObject(SelectCat, GameMain, 984, 230);
				showObject(SelectCat);

				pic = false;
				Magic = false;
			}
		}
		
	}
	else {

	}


	if (obj == StartB) {
		if (StartBVaild) {
			Gamerun = true;
			Gamerun2 = true;
			mixnumber();
			GameReady();
			Timer1();

			StartTIme = time(NULL);
			StartBVaild = false;
		}
	}

	if (obj == RestartB) {
		if (RestartG) {
			for (int i = 0; i < 16; i++) {
				right[i] = false;
			}

			hideObject(UsedOB); hideObject(UsedCat);
			mixnumber();
			GameReady();
			Timer1();
			Magic = true;
			pic = true;
			Gamerun = true;
			Gamerun2 = true;
			RestartG = false;
		}

	}

}


void main() {

	GameMain = createScene("퍼즐맞추기G", "images/GamePrint.png");

	setGameOption(GameOption::GAME_OPTION_INVENTORY_BUTTON, false);
	setGameOption(GameOption::GAME_OPTION_MESSAGE_BOX_BUTTON, false);
	setGameOption(GameOption::GAME_OPTION_ROOM_TITLE, false);

	StartB = createObject("images/StartB.png");
	RestartB = createObject("images/RestartB.png");
	Full_KIKI = createObject("images/KIKI.png");
	item1 = createObject("images/Magi.png");
	item2 = createObject("images/CatsEYE.png");
	locateObject(StartB, GameMain, 23, 220);
	locateObject(RestartB, GameMain, 23, 130);
	locateObject(Full_KIKI, GameMain, 352, 93);
	locateObject(item1, GameMain, 994, 367);
	locateObject(item2, GameMain, 994, 234);
	showObject(StartB); showObject(RestartB); showObject(Full_KIKI); 
	showObject(item1); showObject(item2);

	setMouseCallback(MouseCallback1);
	setTimerCallback(timerCallBack);

	startGame(GameMain);

}